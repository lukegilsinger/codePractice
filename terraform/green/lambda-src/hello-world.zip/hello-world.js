app = () => {
  console.log('hello-world')
  return 1
}

exports.app = app